import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

interface User {
  id: number;
  name: string;
  isFollowed: boolean;
  followRequested: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiUrl = 'http://localhost:8080/user/all';
  private incrementUrl = 'http://localhost:8080/follow/incrementCounts';
  private decrementUrl = 'http://localhost:8080/follow/decrementCounts';
  private followUrl = 'http://localhost:8080/follow/saveByIds';
  private followRequestsUrl = 'http://localhost:8080/follow/followerIdsByFollowingId';

  private usersSubject = new BehaviorSubject<User[]>([]);
  private followRequestsSubject = new BehaviorSubject<User[]>([]);
  private currentUser: { id: number; name: string; followers: number; following: number } = { id: 1, name: '', followers: 0, following: 0 };

  users$ = this.usersSubject.asObservable();
  followRequests$ = this.followRequestsSubject.asObservable();

  constructor(private http: HttpClient) {
    this.fetchUsers();
  }

  fetchUsers() {
    this.http.get<User[]>(this.apiUrl).pipe(
      tap(users => {
        console.log('Fetched users:', users); // Log fetched users
        const filteredUsers = users.filter(user => user.id !== this.currentUser.id);
        this.usersSubject.next(filteredUsers);
      }),
      catchError(error => {
        console.error('Error fetching users', error);
        return of([]); // Return an empty array on error
      })
    ).subscribe();
  }

  fetchFollowRequests() {
    if (!this.currentUser) return;
    this.http.get<User[]>(`${this.followRequestsUrl}/${this.currentUser.id}`).pipe(
      tap(requests => {
        console.log('Fetched follow requests:', requests);
        this.followRequestsSubject.next(requests);
      }),
      catchError(error => {
        console.error('Error fetching follow requests', error);
        return of([]);
      })
    ).subscribe();
  }

  setCurrentUser(user: { id: number; name: string; followers: number; following: number }) {
    this.currentUser = user;
    console.log('Current user set to:', this.currentUser);
    this.fetchUsers();
    this.fetchFollowRequests();
  }

  followUser(userId: number) {
    const users = this.usersSubject.getValue();
    const user = users.find(u => u.id === userId);
    if (user) {
      user.followRequested = true;
      console.log('User follow requested:', user);
      this.usersSubject.next([...users]);

      const params = new HttpParams()
        .set('followerId', this.currentUser.id.toString())
        .set('followingId', user.id.toString());

      this.http.post(this.followUrl, {}, { params }).pipe(
        tap(() => {
          console.log(`Follow request sent for user ID: ${user.id}`);
        }),
        catchError(error => {
          console.error('Error sending follow request', error);
          return of(null);
        })
      ).subscribe();
    }
  }

  unfollowUser(userId: number) {
    const users = this.usersSubject.getValue();
    const user = users.find(u => u.id === userId);
    if (user) {
      user.isFollowed = false;
      user.followRequested = false;
      this.currentUser.following -= 1;

      this.updateCounts(this.currentUser.id, user.id, this.decrementUrl);

      console.log('User unfollowed:', user);
      this.usersSubject.next([...users]);
    }
  }

  acceptFollowRequest(userId: number) {
    const users = this.usersSubject.getValue();
    const user = users.find(u => u.id === userId);
    if (user) {
      user.isFollowed = true;
      user.followRequested = false;
      this.currentUser.followers += 1;
      this.currentUser.following += 1;
      this.updateCounts(this.currentUser.id, user.id, this.incrementUrl);
      console.log('Follow request accepted:', user);
      this.usersSubject.next([...users]);
    }
  }

  ignoreFollowRequest(userId: number) {
    const users = this.usersSubject.getValue();
    const user = users.find(u => u.id === userId);
    if (user) {
      user.followRequested = false;
      console.log('Follow request ignored:', user);
      this.usersSubject.next([...users]);
    }
  }

  updateCounts(followerId: number, followingId: number, url: string) {
    this.http.post(`${url}/${followerId}/${followingId}`, {}).pipe(
      catchError(error => {
        console.error('Error updating counts', error);
        return of(null);
      })
    ).subscribe();
  }

  getCurrentUser() {
    return this.currentUser;
  }

  getUserNameById(userId: number): Observable<{ name: string }> {
    return this.http.get<{ name: string }>(`http://localhost:8080/user/find/${userId}`).pipe(
      catchError(error => {
        console.error('Error fetching user name', error);
        return of({ name: 'Unknown User' });
      })
    );
  }

  getFollowerCount(userId: number): Observable<{ count: number }> {
    return this.http.get<{ count: number }>(`http://localhost:8080/follow/sumFollowerCounts/${userId}`).pipe(
      catchError(error => {
        console.error('Error fetching follower count', error);
        return of({ count: 0 });
      })
    );
  }

  getFollowingCount(userId: number): Observable<{ count: number }> {
    return this.http.get<{ count: number }>(`http://localhost:8080/follow/sumFollowingCounts/${userId}`).pipe(
      catchError(error => {
        console.error('Error fetching following count', error);
        return of({ count: 0 });
      })
    );
  }
}
